package avg.util;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import avg.beans.RawSalaryData;

public class CSVFileReaderTest {

	
	CSVFileReader testService = new CSVFileReader();
	@Test
	public void readDataNegative() {
		/*fail("Not yet implemented");*/
		String filename = null;
		try {
			testService.readData(filename);
			fail("this shoud throw error..");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void readData() {
		/*fail("Not yet implemented");*/
		String filename = "inputData.csv";
		List<RawSalaryData> rawDatas = null;
			try {
			rawDatas = testService.readData(filename);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			assertNotNull(rawDatas);
	}

}
