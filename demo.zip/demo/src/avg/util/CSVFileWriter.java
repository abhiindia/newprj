/**
 * 
 */
package avg.util;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import avg.beans.ResultSalaryData;

/**
 * @author indiahiring
 *
 */
public class CSVFileWriter {

	public static void generateCsvFile(String fileName,
		List<ResultSalaryData> results) {
		FileWriter writer = null;
		try {
			writer = new FileWriter(fileName);
			writer.append("City/Country");
			writer.append(',');
			writer.append("Gender");
			writer.append(',');
			writer.append("Average Income in USD");
			writer.append('\n');
			for (ResultSalaryData rs : results) {
				writer.append(rs.getCity());
				writer.append(',');
				writer.append(rs.getGender());
				writer.append(',');
				writer.append(String.valueOf(rs.getAvgIncome()));
				writer.append('\n');
			}
			System.out.println("CSV file is created...");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				writer.flush();
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
