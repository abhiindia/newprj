/**
 * 
 */
package avg.util;

import avg.constant.SalaryConstants;

/**
 * @author indiahiring
 *
 */
public class CurrencyConvertor {

	public static double inrToUSD(double inr){
		double usd = inr/SalaryConstants.INR;
		return usd;
	}
	
	public static double hkdToUSD(double hkd){
		double usd = hkd/SalaryConstants.INR;
		return usd;
	}
	
	public static double fromUSD(double usd){
		return usd;
	}
	
	public static double sgdToUSD(double sgp){
		double usd = sgp/SalaryConstants.INR;
		return usd;
	}
	
	public static double gbpToUSD(double gbp){
		double usd = gbp/SalaryConstants.INR;
		return usd;
	}
}
