/**
 * 
 */
package avg.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import avg.beans.RawSalaryData;
import avg.service.FileReaderService;

/**
 * @author abhishek
 *
 */
public class CSVFileReader implements FileReaderService{

	public List<RawSalaryData> readData(String fileName) throws FileNotFoundException {
		if(null == fileName || fileName.isEmpty()){
			throw new FileNotFoundException("Please enter correct file name and location..");
		}
		List<RawSalaryData> rawData = new ArrayList<>();
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile,
				StandardCharsets.US_ASCII)) {
			String headers = br.readLine();
			String line = br.readLine();
			while (line != null) {
				String[] attributes = line.split(",");
				if (attributes.length != 0) {
					RawSalaryData rsData = RawSalaryData
							.createResultSalaryData(attributes);
					rawData.add(rsData);
				}
				line = br.readLine();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return rawData;
	}
	
}


