/**
 * 
 */
package avg.constant;

/**
 * @author abhishek
 *
 */
public class SalaryConstants {

	/*Currency values*/
	public static final double INR = 66;
	public static final double GBP = 0.67;
	public static final double SGD = 1.5;
	public static final double HKD = 8;
	
	public static final String INR_CURRENCY = "INR";
	public static final String GBP_CURRENCY = "GBP";
	public static final String SGD_CURRENCY = "SGD";
	public static final String HKD_CURRENCY = "HKD";
}
