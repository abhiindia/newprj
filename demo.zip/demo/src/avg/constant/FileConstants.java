/**
 * 
 */
package avg.constant;

/**
 * @author abhishek
 *
 */
public class FileConstants {

	public static final String CSV_FORMAT = ".csv";
	public static final String XML_FORMAT = ".xml";
	public static final String EXL_FORMAT = ".xlsx";
}
