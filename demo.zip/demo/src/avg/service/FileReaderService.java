package avg.service;

import java.io.FileNotFoundException;
import java.util.List;

import avg.beans.RawSalaryData;

public interface FileReaderService {
	public List<RawSalaryData> readData(String fileName) throws FileNotFoundException;
}
