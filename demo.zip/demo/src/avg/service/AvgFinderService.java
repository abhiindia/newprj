/**
 * 
 */
package avg.service;

/**
 * @author abhishek
 *
 */
public interface AvgFinderService {
	void getAvgIncome(String filename);
}
