/**
 * 
 */
package avg.client;

import avg.service.AvgFinderService;
import avg.serviceimpl.AvgFinderServiceImpl;

/**
 * @author abhishek
 *
 */
public class AvgClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
    AvgFinderService service = new AvgFinderServiceImpl();
    service.getAvgIncome("inputData.csv");

	}

}
