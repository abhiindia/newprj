/**
 * 
 */
package avg.beans;

/**
 * @author abhishek
 *
 */
public class ResultSalaryData implements Comparable<Object> {

	String city;
	String gender;
	double avgIncome;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public double getAvgIncome() {
		return avgIncome;
	}
	public void setAvgIncome(double avgIncome) {
		this.avgIncome = avgIncome;
	}
		
	public String toString(){
		return city + " " + gender + " " + avgIncome;
	}
	@Override
	public int compareTo(Object obj) {
		ResultSalaryData other = (ResultSalaryData) obj;
		if(this.city.compareTo(other.getCity()) == 0){
			return compareObj(other);
		}
		return this.city.compareTo(other.getCity());
	}
	private int compareObj(ResultSalaryData other){
			if(this.gender.compareTo(other.getGender()) > 0){
				return 1;
			}else if(this.gender.compareTo(other.getGender()) < 0){
				return -1;
			}
			return 0;
		}
}
