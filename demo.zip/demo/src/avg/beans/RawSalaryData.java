/**
 * 
 */
package avg.beans;

/**
 * @author abhishek
 *
 */
public class RawSalaryData {

	String country;
	String city;
	String gender;
	String currency;
	double avgIncome;
	
	public static RawSalaryData createResultSalaryData(String []attributs){
		RawSalaryData rsData = new RawSalaryData();
		rsData.setCity(attributs[0]);
		rsData.setCountry(attributs[1]);
		rsData.setGender(attributs[2]);
		rsData.setCurrency(attributs[3]);
		if(null != attributs[4] && !attributs[4].isEmpty()){
		rsData.setAvgIncome(Double.parseDouble(attributs[4]));
		}
		
		return rsData;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public double getAvgIncome() {
		return avgIncome;
	}
	public void setAvgIncome(double avgIncome) {
		this.avgIncome = avgIncome;
	}
	
}
