/**
 * 
 */
package avg.serviceimpl;

import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import avg.beans.RawSalaryData;
import avg.beans.ResultSalaryData;
import avg.constant.FileConstants;
import avg.constant.SalaryConstants;
import avg.service.AvgFinderService;
import avg.service.FileReaderService;
import avg.util.CSVFileReader;
import avg.util.CSVFileWriter;
import avg.util.CurrencyConvertor;

/**
 * @author indiahiring
 *
 */
public class AvgFinderServiceImpl implements AvgFinderService {

	@Override
	public void getAvgIncome(String filename) {
		List<RawSalaryData> rawDatas = new ArrayList<>();
		try {
			if(filename.endsWith(FileConstants.CSV_FORMAT)){
				FileReaderService rService = new CSVFileReader();
			    rawDatas = rService.readData(filename);
			}else if(filename.endsWith(FileConstants.XML_FORMAT)){
				/*Code to call Read xml data method*/
			}else if(filename.endsWith(FileConstants.EXL_FORMAT)){
				/*Code to call Read Excel data method*/
			}
		double avgUsd = 0.0;
		List <ResultSalaryData> results = new ArrayList<>();
		for(RawSalaryData rs: rawDatas){
			if(SalaryConstants.INR_CURRENCY.equals(rs.getCurrency())){
				avgUsd = CurrencyConvertor.inrToUSD(rs.getAvgIncome());
			}else if(SalaryConstants.GBP_CURRENCY.equals(rs.getCurrency())){
				avgUsd = CurrencyConvertor.gbpToUSD(rs.getAvgIncome());
			}else if(SalaryConstants.SGD_CURRENCY.equals(rs.getCurrency())){
				avgUsd = CurrencyConvertor.sgdToUSD(rs.getAvgIncome());
			}else if(SalaryConstants.HKD_CURRENCY.equals(rs.getCurrency())){
				avgUsd = CurrencyConvertor.hkdToUSD(rs.getAvgIncome());
			}
			ResultSalaryData result = createResult(rs, avgUsd);
			results.add(result);
		}
		Collections.sort(results);
		CSVFileWriter.generateCsvFile("outputData.csv", results);
		System.out.println("getAvgIncome completed..");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	private ResultSalaryData createResult(RawSalaryData rs, double avgUsd){
		ResultSalaryData result = new ResultSalaryData();
		result.setAvgIncome(avgUsd);
		result.setCity(rs.getCity());
		result.setGender(rs.getGender());
		
		return result;
	}
	

}
